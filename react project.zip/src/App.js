import "./App.css";
import Body from "./Body";
import Home from "./Home";

function App() {
  return (
    <div className="">
      <Body />
      <Home />
    </div>
  );
}

export default App;
