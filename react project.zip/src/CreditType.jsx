import React, { useState } from "react";
import { MdOutlineCheckBox, MdCheckBoxOutlineBlank } from "react-icons/md";
import { useDispatch, useSelector } from "react-redux";
import { addData, setCardData } from "./store";

const CreditType = ({ value }) => {
  const [isChecked, setIsChecked] = useState(false);
  const dispatch = useDispatch();

  const resultData = useSelector((store) => store.result.data);
  const mockData = useSelector((store) => store.result.cardData);

  const handleSelectOption = () => {
    isChecked ? setIsChecked(false) : setIsChecked(true);

    if (isChecked == false) {
      dispatch(addData(value));
    }
  };


  return (
    <div
      className="credit-type-container"
      onClick={() => {
        handleSelectOption();
        // filterDataItem();
      }}
    >
      {isChecked ? (
        <MdOutlineCheckBox className="credit-type-icon" />
      ) : (
        <MdCheckBoxOutlineBlank className="credit-type-icon" />
      )}
      <p className="credit-type-text">{value}</p>
    </div>
  );
};

export default CreditType;
