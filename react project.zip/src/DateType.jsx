import React, { useState } from "react";
import { MdOutlineCheckBox, MdCheckBoxOutlineBlank } from "react-icons/md";
import { useDispatch, useSelector } from "react-redux";
import { addData, setCardData } from "./store";

const DateType = ({ value }) => {
  const [isChecked, setIsChecked] = useState(false);
  const dispatch = useDispatch();

  const resultData = useSelector((store) => store.result.data);
  const mockData = useSelector((store) => store.result.cardData);

  const handleSelectOption = () => {
    isChecked ? setIsChecked(false) : setIsChecked(true);

    if (isChecked == false) {
      dispatch(addData(value));
    }
  };

  const filteredData = () => {
    const finalFilteredData = [];

    resultData.forEach((ele) => {
      const filterItem = mockData.filter((obj) => {
        return obj.publication_date && obj.publication_date.includes(ele);
      });

      finalFilteredData.push(filterItem);
    });

    dispatch(setCardData(finalFilteredData));
  };

  return (
    <div
      className="date-type-container"
      onClick={() => {
        handleSelectOption();
        filteredData();
      }}
    >
      {isChecked ? (
        <MdOutlineCheckBox className="date-type-icon" />
      ) : (
        <MdCheckBoxOutlineBlank className="date-type-icon" />
      )}
      <p className="date-type-text">{value}</p>
    </div>
  );
};

export default DateType;
