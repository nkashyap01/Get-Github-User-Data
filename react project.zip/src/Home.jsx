import React, { useState } from "react";
import { FaCaretDown, FaCaretUp } from "react-icons/fa";
import CreditType from "./CreditType";
import { useDispatch, useSelector } from "react-redux";
import { IoSearch } from "react-icons/io5";
import Card from "./Card";
import DateType from "./DateType";
import { RxCross2 } from "react-icons/rx";
import { clearData, setCardData } from "./store";

const Home = () => {
  const [isShowCredit, setIsShowCredit] = useState(false);
  const [isShowDate, setIsShowDate] = useState(false);
  const [isDownCredit, setIsDownCredit] = useState(true);
  const [isDownDate, setIsDownDate] = useState(true);
  const dispatch = useDispatch();

  const resultData = useSelector((store) => store.result.data);
  const mockData = useSelector((store) => store.result.cardData);

  if (!mockData) return null;

  // const creditOptions = [
  //   "CE (255)",
  //   "CME (156)",
  //   "CPEU (252)",
  //   "Non-Accredited (1)",
  // ];

  // const dateOptions = [
  //   "2017 (8)",
  //   "2018 (16)",
  //   "2019 (24)",
  //   "2020 (51)",
  //   "2021 (59)",
  //   "2022 (67)",
  //   "2023 (51)",
  //   "2024 (1)",
  // ];

  const creditOptions = ["CE", "CME", "CPEU", "Non-Accredited"];

  const dateOptions = [
    "2017",
    "2018",
    "2019",
    "2020",
    "2021",
    "2022",
    "2023",
    "2024",
  ];

  const handleFilter = () => {
    dispatch(clearData());
  };

  const handleCreditShow = () => {
    setIsShowCredit(true);
    setIsDownCredit(false);
  };
  const handleCreditHide = () => {
    setIsShowCredit(false);
    setIsDownCredit(true);
  };
  const handleDateShow = () => {
    setIsShowDate(true);
    setIsDownDate(false);
  };
  const handleDateHide = () => {
    setIsShowDate(false);
    setIsDownDate(true);
  };

  if (!resultData) return null;

  return (
    <div className="filter-container">
      <div className="filter-content">
        <h3 className="filter-title">FILTER RESULTS</h3>

        <div className="filter-options">
          <div className="filter-button-container">
            <button
              onMouseEnter={() => handleCreditShow()}
              onMouseLeave={() => handleCreditHide()}
              className="filter-button"
            >
              CREDIT TYPE{" "}
              {isDownCredit ? (
                <FaCaretDown className="inline text-xl" />
              ) : (
                <FaCaretUp className="inline text-xl" />
              )}
            </button>
            {isShowCredit && (
              <div
                onMouseEnter={() => handleCreditShow()}
                onMouseLeave={() => handleCreditHide()}
                className="filter-dropdown"
              >
                {creditOptions.map((ele, index) => {
                  return <CreditType key={index} value={ele} />;
                })}
              </div>
            )}
          </div>
          <div className="filter-button-container ml-2">
            <button
              onMouseEnter={() => handleDateShow()}
              onMouseLeave={() => handleDateHide()}
              className="filter-button"
            >
              DATE
              {isDownDate ? (
                <FaCaretDown className="inline text-xl" />
              ) : (
                <FaCaretUp className="inline text-xl" />
              )}
            </button>
            {isShowDate && (
              <div
                onMouseEnter={() => handleDateShow()}
                onMouseLeave={() => handleDateHide()}
                className="filter-dropdown"
              >
                {dateOptions.map((ele, index) => {
                  return <DateType key={index} value={ele} />;
                })}
              </div>
            )}
          </div>
        </div>

        <div>
          <input
            className="filter-input"
            type="text"
            placeholder="FILTER BY KEYWORDS"
          />
          <button className="filter-search-button">
            <IoSearch className="text-white" />
          </button>
        </div>

        <div className="filter-result-info">
          <p>Showing 1-10 of 262 results</p>
          <p>
            Sort by : <span className="font-bold">RELEVANCE</span>
          </p>
        </div>

        <div className="filter-results">
          <div className="filter-result-item">
            {resultData.map((data) => {
              return (
                <div className="cross-card">
                  <p>{data}</p>
                  <div
                    style={{
                      display: "flex",
                      backgroundColor: "white",
                      padding: "2px 4px",
                      borderRadius: "10px",
                      cursor: "pointer",
                    }}
                  >
                    <RxCross2 />
                  </div>
                </div>
              );
            })}
          </div>
          <button
            style={{ padding: "2px 4px" }}
            onClick={() => handleFilter()}
            className="filter-clear-button"
          >
            Clear All Filter
          </button>
        </div>

        <div className="filter-card-container">
          {mockData.map((card) => (
            <Card key={card.id} resultData={card} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default Home;
