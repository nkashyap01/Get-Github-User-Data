import { configureStore } from "@reduxjs/toolkit";
import { createSlice } from "@reduxjs/toolkit";

const appSlice = createSlice({
  name: "result",
  initialState: {
    data: ["French"],
    cardData: [
      {
        title:
          "NUTRITION-FOCUSED PHYSICAL EXAM - PART 1: SUBCUTANEOUS FAT AND MUSCLE LOSS",
        publication_date: "Jan 09, 2019",
        language: "English",
        description:
          "In this course, Nancy Munoz, DCN, MHA, RDN, FAND, and Megan Norwood, MBA, MS, RDN, LD, CNSC will review current evidence-based nutrition care recommendations for the prevention and treatment of Pressure Injuries (PIs), discuss the role and implementation of the newly released Standardized Pressure Injury Prevention Protocol Checklist (SPIPP-Adult) 2.0, describe the process for healthcare professionals to implement nutrition care recommendations into actionable steps and include them as part of a patient plan of care, and more! Originally presented as a live webinar on August 23, 2023.",
        continuesData: "NurseContact: 1.0 DietitianCPEU: 1.0",
        run_time: "59 Mins",
        link: "https://anhi.org/education/course-catalog/E26B4E4ECE824A0D97BA9A062B688B6B",
      },

      {
        title:
          "NUTRITION AND WOUNDS: IMPLEMENTING AN EVIDENCE-BASED PLAN OF CARE",
        publication_date: "Dec 21, 2023",
        language: "English",
        description:
          "In this course, Nancy Munoz, DCN, MHA, RDN, FAND, and Megan Norwood, MBA, MS, RDN, LD, CNSC will review current evidence-based nutrition care recommendations for the prevention and treatment of Pressure Injuries (PIs), discuss the role and implementation of the newly released Standardized Pressure Injury Prevention Protocol Checklist (SPIPP-Adult) 2.0, describe the process for healthcare professionals to implement nutrition care recommendations into actionable steps and include them as part of a patient plan of care, and more! Originally presented as a live webinar on August 23, 2023.",
        continuesData: `NurseContact: 1.0,
          DietitianCPEU: 1.0,
          PhysicianCME: 1.0,`,
        run_time: "30 Mins",
        link: "https://anhi.org/education/course-catalog/4D67F6C3C66F4FA788C9CDBCFF0CF930",
      },

      {
        title: "THE NUTRITION-FOCUSED PHYSICAL EXAM",
        publication_date: "Jul 25, 2022",
        language: "English",
        description:
          "In this two-part series, youll review the prevalence of malnutrition in the adult population, learn now to help identify malnutrition and micronutrient deficiencies, evaluate muscle and fat loss, and more. [FREE Continuing Education: 1.0 RN CE, 1.0 RD CPEU per course]",
        continuesData: "CE",
        link: "https://anhi.org/education/course-catalog/NFPE-1and2",
      },

      {
        title: "ADDRESSING WEIGHT STIGMA IN THE HEALTHCARE SETTING",
        publication_date: "Dec 21, 2023",
        language: "English",
        description:
          "In this course, Laura Andromalos, MS, RN, RD, CSOWM, CDCES will discuss the concepts of weight stigma and the obesity paradox, discuss respectful language guidelines, and review how healthcare professionals can address weight stigma. Originally presented as a live webinar on July 18, 2023.",
        continuesData: "MCE",
        run_time: "33 Mins",
        link: "https://anhi.org/education/course-catalog/45E327100CBA42938C8708755BE70069",
      },

      {
        title: "BENEFITS OF BREASTFEEDING",
        publication_date: "Feb 13, 2023",
        language: "English",
        description:
          "In this course, Michelle L. Arrizola, MBA, RN, BSN, IBCLC will discuss the benefits of breastfeeding for mom and baby, review breast anatomy and how breastmilk is produced, identify the 3 stages of breastmilk production, and describe successful breastfeeding techniques and how the healthcare professional can support the family.",
        continuesData: "PCEM",
        run_time: "34 Mins",
        link: "https://anhi.org/education/course-catalog/42D41AD696BC4C939C4C4F1BC8850C88",
      },
      {
        title:
          "MISE À JOUR SCIENTIFIQUE SUR DE NOUVEAUX CONCEPTS EN MATIÈRE DE NUTRITION CHEZ LES PATIENTS DIABÉTIQUES: ALGORITHME TRANSCULTUREL DE PRISE EN CHARGE NUTRITIONNELLE DU DIABÈTE ET RÉMISSION DU DIABÈTE",
        publication_date: "Jan 13 2022",
        language: "French",
        description:
          "Dans le cadre de ce cours, vous en apprendrez plus sur les concepts relatifs à la prise en charge nutritionnelle du diabète de type 2, vous soulignerez le rôle des préparations spécialement conçues pour les personnes diabétiques dans la prise en charge de lobésité et du diabète et vous parlerez des effets dune planification structurée de lalimentation dans la prise en charge du poids et du diabète. Ce cours a été présenté pour la première fois comme webinaire en direct le 24 juin 2021.",
        run_time: "18 Mins",
        continuesData: "CE",
        link: "https://anhi.org/ca/fr/education/course-catalog/CFAE711D0A1141EA83735F2A8EC683A3",
      },
      {
        title:
          "LE 2'-FUCOSYLLACTOSE : UN OLIGOSACCHARIDE DE LAIT HUMAIN MODULANT LES ALLERGIES",
        publication_date: "Apr 08 2021",
        language: "French",
        description:
          "Dans le cadre du cours, vous passerez en revue les études cliniques qui appuient les bienfaits immunitaires du 2'-fucosyllactose (2'-FL), un oligosaccharide de lait humain (OLH), vous discuterez des données précliniques étayant les effets du 2'-FL sur les allergies alimentaires et ses modes d’action potentiels et vous décrirez le rôle possible du 2'-FL sur lamélioration de la tolérance orale. Ce cours a été présenté pour la première fois comme webinaire en direct le 3 juin 2020.",
        run_time: "51 Mins",
        link: "https://anhi.org/ca/fr/education/course-catalog/511CC4974C274020B9C0F3FFFD407039",
      },
      {
        title: "COMPOSITION CORPORELLE ET SANTÉ : MODULE 2",
        publication_date: "Aug 17 2023",
        language: "French",
        description:
          "Dans la deuxième partie de ce cours en 2 parties, vous serez en mesure de résumer le modèle à cinq niveaux de composition corporelle humaine, dénumérer les techniques dévaluation de la composition corporelle associées à chaque niveau du modèle, de montrer comment utiliser lanalyse dimpédance bioélectrique et les tomodensitogrammes pour évaluer la composition corporelle en pratique clinique, et plus encore.",
        run_time: "67 Mins",
        continuesData: "MCE",
        link: "https://anhi.org/ca/fr/education/course-catalog/0DD39D754277432E8BEA5B26A555D8AB",
      },
      {
        title:
          "ÉNONCÉ CONSENSUEL MONDIAL SUR LES RÉPERCUSSIONS DU TRAITEMENT NUTRITIONNEL MÉDICAL ET DES PRÉPARATIONS SPÉCIALEMENT CONÇUES POUR LES PERSONNES DIABÉTIQUES",
        publication_date: "Dec 02 2021",
        language: "French",
        description:
          "Dans le cadre du cours, vous en apprendrez plus sur le rôle du traitement nutritionnel médical et des préparations spécialement conçues pour les personnes diabétiques dans lamélioration des résultats chez les personnes atteintes de diabète, vous discuterez de la nécessité dun consensus mondial sur lutilisation du traitement nutritionnel médical chez les personnes diabétiques et vous passerez en revue le nouvel énoncé consensuel mondial sur les répercussions du traitement nutritionnel médical et des préparations spécialement conçues pour les personnes diabétiques sur les facteurs de risque métabolique et cardiovasculaire. Ce cours a été présenté pour la première fois comme webinaire en direct le 24 juin 2021.",
        run_time: "20 Mins",
        link: "https://anhi.org/ca/fr/education/course-catalog/46D9E68D99354A7FBF0ED7F67AE22328",
      },
      {
        title: "ALIMENTATION ENTÉRALE PAR SONDE 101",
        publication_date: "Jan 20 2021",
        language: "French",
        description:
          "Dans ce cours, vous en apprendrez davantage sur lalimentation entérale par sonde et discuterez des différentes indications et contre-indications dutilisation de cette technique, vous apprendrez à reconnaître les types de dispositifs accès aux voies entérales, vous passerez en revue les classifications des préparations entérales, et vous apprendrez à différencier les méthodes de lalimentation entérale (en bolus, intermittente, cyclique et en continu).",
        run_time: "54 Mins",
        continuesData: "PCME",
        link: "https://anhi.org/ca/fr/education/course-catalog/E86D2B87C33849D18346FA46C3542B45",
      },
      {
        title: "COMPOSITION CORPORELLE ET SANTÉ: MODULE 1",
        publication_date: "Aug 17 2023",
        language: "French",
        description:
          "Dans la première partie de ce cours en 2 parties, vous définirez la composition corporelle et passerez en revue sa terminologie, vous ferez la distinction entre lindice de masse corporelle et la composition corporelle, vous résumerez les techniques dévaluation de la composition corporelle, et plus encore.",
        continuesData: "CE",
        link: "https://anhi.org/ca/fr/education/course-catalog/12B92D4011854ECEAD6A046F4756216E",
      },
      {
        title:
          "EXAMEN PHYSIQUE AXÉ SUR LA NUTRITION  PARTIE 2 : MICRONUTRIMENTS, ACCUMULATION DE LIQUIDE ET ÉTAT FONCTIONNEL",
        publication_date: "Sep 07 2023",
        language: "French",
        description:
          "Voici la deuxième partie dun cours en 2 parties. Dans ce cours, vous discuterez de la façon dévaluer les carences en micronutriments chez les patients adultes, vous résumerez les types et les stades de lœdème, vous passerez en revue la façon deffectuer une évaluation de la force de préhension, et vous regarderez des démonstrations sur la façon de déceler les carences en micronutriments et de déterminer létat fonctionnel.",
        run_time: "44 Mins",
        link: "https://anhi.org/ca/fr/education/course-catalog/F1C79599F5B749AFBD050C00AF0AEB89",
      },
      {
        title: "EXAMEN PHYSIQUE PÉDIATRIQUE AXÉ SUR LA NUTRITION",
        publication_date: "Aug 31 2023",
        language: "French",
        description:
          "Dans ce cours, vous expliquerez la raison dêtre dun examen physique axé sur la nutrition chez les patients pédiatriques, vous discuterez du rôle de cet examen dans lidentification de la malnutrition, vous décèlerez les signes cliniques des carences nutritionnelles et des toxicités courantes, et vous évaluerez létat dhydratation.",
        run_time: "49 Mins",
        link: "https://anhi.org/ca/fr/education/course-catalog/EE37C82624B64EC495B4A4CFFD5C95C5",
      },
      {
        title:
          "EXAMEN PHYSIQUE AXÉ SUR LA NUTRITION  PARTIE 1 : PERTE DE GRAISSE SOUS-CUTANÉE ET PERTE MUSCULAIRE",
        publication_date: "Sep 07 2023",
        language: "French",
        description:
          "Voici la première parie dun cours en 2 parties. Dans cette partie, vous passerez en revue la prévalence de la malnutrition et la détection de la malnutrition chez ladulte, vous discuterez de la façon dévaluer les pertes musculaires et adipeuses chez les patients adultes, et vous regarderez des démonstrations sur la façon dévaluer les changements dans la composition corporelle à laide de lexamen physique axé sur la nutrition.",
        run_time: "59 Mins",
        link: "https://anhi.org/ca/fr/education/course-catalog/A459FDD12A374C3C8C557FC005FBABBB",
      },
      {
        title:
          "PEDIATRIC CURRENTS: SCREENING FOR MALNUTRITION RISK IN PEDIATRICS",
        publication_date: "May 30 2019",
        language: "French",
        description:
          "In this course, Patricia Becker MS, RDN, CSP, CNSC, FAND, will teach you the value of screening children for malnutrition, define the terms nutrition screen and nutrition assessment, and identify four pediatric nutrition screening tools that have been clinically validated.",
        continuesData: "CE",
        link: "https://anhi.org/ca/fr/education/course-catalog/3940764A212049D9B2EADD32B4B0F0A8",
      },
      {
        title:
          "LE RÔLE DU 2'-FL DANS LINFLAMMATION ET SON RÔLE POSSIBLE DANS LES ALLERGIES ALIMENTAIRES",
        publication_date: "Aug 19 2021",
        language: "French",
        description:
          "Dans le cadre de ce cours, vous examinerez les recherches sur les façons dont le 2-FL, un oligosaccharide de lait humain (OLH), contribue à amenuiser les différences entre les préparations pour nourrissons et le lait maternel, vous passerez en revue les études cliniques montrant les bienfaits des OLH sur le système immunitaire et vous discuterez des raisons pour lesquelles le 2-FL peut être pertinent dans la prise en charge alimentaire des nourrissons présentant des allergies alimentaires. Ce cours a été présenté pour la première fois comme webinaire en direct le 7 avril 2021.",
        run_time: "52 Mins",
        continuesData: "PCME",
        link: "https://anhi.org/ca/fr/education/course-catalog/F2993AB93F3E434C98975839BD8AACA5",
      },
    ],
  },
  reducers: {
    addData: (state, action) => {
      state.data.push(action.payload);
    },
    clearData: (state) => {
      state.data = [];
    },
    setCardData: (state, action) => {
      state.cardData.push(action.payload);
    },
  },
});

const appStore = configureStore({
  reducer: {
    result: appSlice.reducer,
  },
});

export default appStore;
export const { addData, setCardData, clearData } = appSlice.actions;
