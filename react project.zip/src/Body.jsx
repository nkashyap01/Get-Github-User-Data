import React from "react";


const Body = () => {
  return (
    <div className="body">
      <ul className="list">
        <li>Home/</li>
        <li>Education/</li>
        <li>Course/</li>
        <li>Catalog</li>
      </ul>
      <div className="background-image relative"></div>
      <div className="absolute-container">
        <div className="p-2">
          <h1 className="text-white text-heading">
            OFFERING TRADITIONAL AND REFLECTIVE LEARNING APPROACHES
          </h1>
        </div>
        <p className="text-white mt-8">
          Browse the ANHI Course Catalog for CME, CE and CPEU offerings. Enter a
          keyword in the search field below. Use the search filters to further
          scan and sort your results.
        </p>
        <a
          className="border-2 rounded-2xl background-green text-white text-large padding-x"
          href="https://static.abbottnutrition.com/cms-prod/anhi-2017.org/img/2023%20Q4%20CE%20Program%20Brochure_tcm1423-169785.pdf"
        >
          ANHI CONTINUING EDUCATION BROCHURE (PDF 1.53 MB)
        </a>
      </div>
    </div>
  );
};

export default Body;
