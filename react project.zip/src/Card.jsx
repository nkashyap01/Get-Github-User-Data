import React from "react";
import { PiLinkSimpleBold } from "react-icons/pi";

const Card = ({ resultData }) => {
  const {
    title,
    publication_date,
    language,
    description,
    continuesData,
    run_time,
    link,
  } = resultData;

  return (
    <div className="card">
      <h3>{title}</h3>
      <div className="flex">
        <p className="font-bold">
          Publication Date:{" "}
          <span className="font-normal">{publication_date}</span>
        </p>
        <div className="flex gap-1 items-center language-flag">
          <img
            className="h-4"
            src="https://cdn.britannica.com/79/4479-050-6EF87027/flag-Stars-and-Stripes-May-1-1795.jpg"
            alt=""
          />
          <p>{language}</p>
        </div>
      </div>
      <p>{description}</p>
      <div className="flex">
        <p className="font-bold ce-units">Continuing Education Units:</p>
        <p className="pl-1">{continuesData}</p>
      </div>
      <p className="font-bold run-time">
        Run Time : <span className="font-normal">{run_time}</span>
      </p>
      <div className="flex gap-1 items-center link-container">
        <PiLinkSimpleBold className="font-bold" />
        <a href={link}>{link}</a>
      </div>
    </div>
  );
};

export default Card;
